package model;

public class ScoreTooHighException extends Exception{
}
