package model;

// EFFECTS: sets the enumeration values for Severity
public enum Severity {
    MINIMAL, MILD, MODERATE, SEVERE
}
